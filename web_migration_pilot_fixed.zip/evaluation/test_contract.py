import requests

BASE = "http://127.0.0.1:5056"

def test_health():
    r = requests.get(BASE + "/health", timeout=5)
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}

def test_user():
    r = requests.get(BASE + "/users/1", timeout=5)
    assert r.status_code == 200
    assert r.json()["name"] == "Alice"

def test_missing_user():
    r = requests.get(BASE + "/users/999", timeout=5)
    assert r.status_code == 404
    assert r.json()["error"] == "user_not_found"

def test_product_search():
    r = requests.get(BASE + "/products", params={"q": "pen"}, timeout=5)
    assert r.status_code == 200
    assert r.json()["count"] == 1
    assert r.json()["items"][0]["name"] == "Pen"

def test_category():
    r = requests.get(BASE + "/products", params={"category": "stationery"}, timeout=5)
    assert r.status_code == 200
    assert r.json()["count"] == 2

def test_login_me():
    s = requests.Session()
    r = s.post(BASE + "/login", json={"user_id": "2"}, timeout=5)
    assert r.status_code == 200
    r = s.get(BASE + "/me", timeout=5)
    assert r.status_code == 200
    assert r.json()["name"] == "Bob"

def test_authz():
    s = requests.Session()
    s.post(BASE + "/login", json={"user_id": "2"}, timeout=5)
    assert s.get(BASE + "/admin", timeout=5).status_code == 403

def test_admin():
    s = requests.Session()
    s.post(BASE + "/login", json={"user_id": "1"}, timeout=5)
    assert s.get(BASE + "/admin", timeout=5).json()["message"] == "admin_ok"

def test_redirect():
    r = requests.get(BASE + "/old-home", allow_redirects=False, timeout=5)
    assert r.status_code == 302
    assert r.headers["Location"] == "/health"
