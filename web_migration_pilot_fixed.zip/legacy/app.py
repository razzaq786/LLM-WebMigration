from flask import Flask, request, jsonify, session, redirect

app = Flask(__name__)
app.secret_key = "legacy-demo-secret"

USERS = {
    "1": {"id": 1, "name": "Alice", "role": "admin"},
    "2": {"id": 2, "name": "Bob", "role": "user"},
    "3": {"id": 3, "name": "Carol", "role": "user"},
}

PRODUCTS = [
    {"id": 1, "name": "Notebook", "category": "stationery", "price": 5.50},
    {"id": 2, "name": "Pen", "category": "stationery", "price": 1.25},
    {"id": 3, "name": "Mug", "category": "home", "price": 8.00},
]

@app.get("/health")
def health():
    return jsonify({"status": "ok"})

@app.get("/users/<user_id>")
def user(user_id):
    u = USERS.get(user_id)
    return jsonify(u) if u else (jsonify({"error": "user_not_found"}), 404)

@app.get("/products")
def products():
    q = request.args.get("q", "").strip().lower()
    category = request.args.get("category")
    items = PRODUCTS
    if q:
        items = [p for p in items if q in p["name"].lower()]
    if category:
        items = [p for p in items if p["category"] == category]
    return jsonify({"count": len(items), "items": items})

@app.post("/login")
def login():
    body = request.get_json(silent=True) or {}
    user_id = str(body.get("user_id", ""))
    u = USERS.get(user_id)
    if not u:
        return jsonify({"error": "invalid_credentials"}), 401
    session["user_id"] = u["id"]
    return jsonify({"message": "logged_in", "user": u})

@app.get("/me")
def me():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"error": "not_authenticated"}), 401
    u = USERS.get(str(uid))
    return jsonify(u) if u else (jsonify({"error": "session_user_missing"}), 401)

@app.get("/admin")
def admin():
    uid = session.get("user_id")
    if not uid:
        return jsonify({"error": "not_authenticated"}), 401
    u = USERS.get(str(uid))
    if not u or u["role"] != "admin":
        return jsonify({"error": "forbidden"}), 403
    return jsonify({"message": "admin_ok"})

@app.get("/old-home")
def old_home():
    return redirect("/health", code=302)

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5056)
