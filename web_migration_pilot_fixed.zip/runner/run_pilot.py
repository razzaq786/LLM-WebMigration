import os
import re
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

from hf_client import call

ROOT = Path(__file__).resolve().parents[1]
LEGACY = (ROOT / "legacy" / "app.py").read_text(encoding="utf-8")
GEN = ROOT / "generated"
RES = ROOT / "results"
GEN.mkdir(exist_ok=True)
RES.mkdir(exist_ok=True)

SYSTEM = """You are an expert Web software engineer performing a controlled
legacy Web modernization experiment. Modernize the supplied Flask application
into a modular Flask application with app.py, routes.py, services.py and
repository.py. Preserve every observable endpoint, HTTP status, JSON field,
redirect, session and authorization behavior. Do not weaken security.

Return ONLY complete files using this exact format:
=== FILE: app.py ===
<content>
=== FILE: routes.py ===
<content>
=== FILE: services.py ===
<content>
=== FILE: repository.py ===
<content>

The application must run with `python app.py` on port 5056.
"""

def extract_files(text):
    """Extract generated files, tolerating an optional Markdown code fence."""
    if not isinstance(text, str):
        raise TypeError(f"Expected model text, got {type(text).__name__}")

    text = text.replace("```python", "").replace("```text", "").replace("```", "")
    pattern = re.compile(
        r"===\s*FILE:\s*([A-Za-z0-9_.\-/]+)\s*===\s*\n"
        r"(.*?)(?=\n===\s*FILE:|\Z)",
        re.S,
    )
    found = pattern.findall(text)
    return {name.strip(): content.strip() + "\n" for name, content in found}

def generated_text(response):
    """Normalize a direct response or a staged/closed-loop response."""
    if isinstance(response, dict) and "text" in response:
        return response["text"]
    if isinstance(response, dict) and "code" in response:
        return generated_text(response["code"])
    raise KeyError("No model text found in response.")

def write_files(files, destination):
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    for name, content in files.items():
        p = destination / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")

def start_app(destination):
    return subprocess.Popen(
        [sys.executable, "app.py"],
        cwd=destination,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

def run_tests(destination):
    process = start_app(destination)
    time.sleep(2)
    try:
        result = subprocess.run(
            [
                sys.executable, "-m", "pytest",
                str(ROOT / "evaluation" / "test_contract.py"),
                "-q",
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=45,
        )
    finally:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()
    return result.returncode, result.stdout + "\n" + result.stderr

def evaluate(name, response):
    text = generated_text(response)
    files = extract_files(text)
    destination = GEN / name
    write_files(files, destination)

    if "app.py" not in files:
        return {
            "files": sorted(files),
            "pass": False,
            "output": "No app.py was generated.",
        }

    rc, output = run_tests(destination)
    return {
        "files": sorted(files),
        "pass": rc == 0,
        "output": output,
    }

def direct():
    return call([
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": f"""Perform a one-shot migration.

LEGACY APPLICATION:
```python
{LEGACY}
```"""},
    ])

def staged():
    plan = call([
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": f"""Analyze this legacy Web application and
produce a migration plan. Identify endpoints, externally observable behavior,
sessions, authorization, data access and target module responsibilities.
Do not write code yet.

LEGACY:
{LEGACY}"""},
    ], max_tokens=7000)

    code = call([
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": f"""Implement the following migration plan.
Return complete app.py, routes.py, services.py and repository.py.

PLAN:
{plan["text"]}

LEGACY:
{LEGACY}"""},
    ])

    return {"plan": plan, "code": code}

def closed_loop():
    staged_result = staged()
    current = staged_result["code"]
    history = []

    for cycle in range(3):
        evaluation = evaluate("closed_loop", current)
        history.append({
            "cycle": cycle + 1,
            "evaluation": evaluation,
        })

        if evaluation["pass"]:
            break

        current = call([
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": f"""Repair the migrated application
using the independent test failure below. Return ALL complete files.

Do not remove or weaken authentication/authorization. Do not modify the tests.
Preserve the legacy behavior.

TEST FAILURE:
{evaluation["output"][-12000:]}

LEGACY:
{LEGACY}"""},
        ])

    return {
        "initial_plan": staged_result["plan"],
        "initial_code": staged_result["code"],
        "final_code": current,
        "cycles": len(history),
        "history": history,
    }

def main():
    if not os.getenv("HF_TOKEN"):
        raise SystemExit("HF_TOKEN is not configured.")

    raw = {
        "experiment": "pilot",
        "model": os.getenv("HF_MODEL", "deepseek-ai/DeepSeek-V3-0324"),
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }

    print("[1/3] Running Direct treatment...")
    direct_result = direct()
    raw["direct"] = {
        "llm": direct_result,
        "evaluation": evaluate("direct", direct_result),
    }

    print("[2/3] Running Staged treatment...")
    staged_result = staged()
    raw["staged"] = {
        "llm": staged_result,
        "evaluation": evaluate("staged", staged_result),
    }

    print("[3/3] Running Closed-loop treatment...")
    raw["closed_loop"] = closed_loop()

    output = RES / "pilot_raw.json"
    output.write_text(
        json.dumps(raw, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print("\nPILOT_COMPLETE")
    print(f"Raw evidence: {output}")
    print("Generated applications: generated/")

if __name__ == "__main__":
    main()
