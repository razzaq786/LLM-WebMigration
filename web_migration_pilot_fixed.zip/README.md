# Verification-Controlled LLM Web Migration — Pilot

This pilot performs real Hugging Face inference calls and compares:
1. Direct LLM migration
2. Staged LLM migration
3. Closed-loop migration with independent executable verification and bounded repair

The three treatments use the same model and the same legacy Web application.

## Run

PowerShell:

```powershell
$env:HF_TOKEN="hf_YOUR_NEW_TOKEN"
$env:HF_MODEL="deepseek-ai/DeepSeek-V3-0324"
pip install -U openai Flask requests pytest
python runner/run_pilot.py
```

The actual evidence is written to:
`results/pilot_raw.json`

Generated applications are written to:
`generated/direct`, `generated/staged`, `generated/closed_loop`

This is a pilot. Do not treat it as the final multi-application statistical study.
Do not put the Hugging Face token into source files or Git.
