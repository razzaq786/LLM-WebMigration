import os
import requests
B='http://127.0.0.1:5061'
def test_hidden():
 assert requests.get(B+'/products/999').status_code==404
 assert requests.get(B+'/products',params={'category':'home'}).json()['count']==1
 assert requests.get(B+'/old-home',allow_redirects=False).headers['location']=='/health'
