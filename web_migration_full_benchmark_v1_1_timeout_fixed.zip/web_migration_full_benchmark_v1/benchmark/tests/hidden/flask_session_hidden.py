import os
import requests
B='http://127.0.0.1:5060'
def test_hidden():
 assert requests.get(B+'/users/999').status_code==404
 assert requests.get(B+'/products',params={'category':'stationery'}).json()['count']==2
 assert requests.post(B+'/login',json={'user_id':'999'}).status_code==401
 assert requests.get(B+'/me').status_code==401
 s=requests.Session();s.post(B+'/login',json={'user_id':'1'});assert s.get(B+'/admin').json()['message']=='admin_ok'
 assert requests.get(B+'/old-home',allow_redirects=False).headers['Location']=='/health'
