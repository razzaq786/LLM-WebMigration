import os
import requests
B='http://127.0.0.1:5062'
def test_hidden():
 assert requests.get(B+'/orders/999').status_code==404
 assert requests.get(B+'/orders',params={'status':'paid'}).json()['count']==1
