import os
import requests
B='http://127.0.0.1:5062'
def test_all():
 assert requests.get(B+'/health').json()=={'status':'ok'}
 assert requests.get(B+'/orders/1').json()['customer']=='Alice'
 assert requests.get(B+'/orders',params={'status':'pending'}).json()['count']==1
 assert requests.post(B+'/orders',json={'customer':'Carol','status':'paid'}).status_code==200
