import os
import requests
B='http://127.0.0.1:5060'
def test_all():
 assert requests.get(B+'/health').json()=={'status':'ok'}
 assert requests.get(B+'/users/1').json()['name']=='Alice'
 assert requests.get(B+'/products',params={'q':'pen'}).json()['count']==1
 s=requests.Session(); assert s.post(B+'/login',json={'user_id':'2'}).status_code==200
 assert s.get(B+'/me').json()['name']=='Bob'; assert s.get(B+'/admin').status_code==403
 assert requests.get(B+'/old-home',allow_redirects=False).status_code==302
