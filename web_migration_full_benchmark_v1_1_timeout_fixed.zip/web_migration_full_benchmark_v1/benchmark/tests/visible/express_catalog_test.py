import os
import requests
B='http://127.0.0.1:5061'
def test_all():
 assert requests.get(B+'/health').json()=={'status':'ok'}
 assert requests.get(B+'/products',params={'q':'pen'}).json()['count']==1
 assert requests.get(B+'/products/2').json()['name']=='Pen'
 assert requests.post(B+'/echo',json={'x':1}).json()['received']['x']==1
