const express=require('express'); const app=express(); app.use(express.json());
const products=[{id:1,name:'Notebook',category:'stationery',price:5.5},{id:2,name:'Pen',category:'stationery',price:1.25},{id:3,name:'Mug',category:'home',price:8}];
app.get('/health',(q,r)=>r.json({status:'ok'}));
app.get('/products',(q,r)=>{let x=products;if(q.query.q)x=x.filter(p=>p.name.toLowerCase().includes(q.query.q.toLowerCase()));if(q.query.category)x=x.filter(p=>p.category===q.query.category);r.json({count:x.length,items:x})});
app.get('/products/:id',(q,r)=>{const p=products.find(x=>x.id===Number(q.params.id));p?r.json(p):r.status(404).json({error:'product_not_found'})});
app.post('/echo',(q,r)=>r.json({received:q.body||{}}));
app.get('/old-home',(q,r)=>r.redirect(302,'/health')); app.listen(5061,'127.0.0.1');
