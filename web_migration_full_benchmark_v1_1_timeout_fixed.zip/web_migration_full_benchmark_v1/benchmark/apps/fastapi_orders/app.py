from fastapi import FastAPI,HTTPException
from pydantic import BaseModel
app=FastAPI(); ORDERS={1:{'id':1,'customer':'Alice','status':'paid'},2:{'id':2,'customer':'Bob','status':'pending'}}
class Order(BaseModel): customer:str; status:str
@app.get('/health')
def health(): return {'status':'ok'}
@app.get('/orders/{oid}')
def get_order(oid:int):
 if oid not in ORDERS: raise HTTPException(404,'order_not_found')
 return ORDERS[oid]
@app.post('/orders')
def create(o:Order):
 oid=max(ORDERS)+1; ORDERS[oid]={'id':oid,**o.model_dump()}; return ORDERS[oid]
@app.get('/orders')
def list_orders(status:str|None=None):
 x=list(ORDERS.values()); x=[o for o in x if not status or o['status']==status]; return {'count':len(x),'items':x}
