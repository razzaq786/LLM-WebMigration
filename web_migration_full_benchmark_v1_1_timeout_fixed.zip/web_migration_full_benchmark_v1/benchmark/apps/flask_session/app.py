from flask import Flask, request, jsonify, session, redirect
app=Flask(__name__); app.secret_key='legacy-secret'
USERS={'1':{'id':1,'name':'Alice','role':'admin'},'2':{'id':2,'name':'Bob','role':'user'}}
PRODUCTS=[{'id':1,'name':'Notebook','category':'stationery','price':5.5},{'id':2,'name':'Pen','category':'stationery','price':1.25},{'id':3,'name':'Mug','category':'home','price':8.0}]
@app.get('/health')
def health(): return jsonify({'status':'ok'})
@app.get('/users/<uid>')
def users(uid): return jsonify(USERS[uid]) if uid in USERS else (jsonify({'error':'user_not_found'}),404)
@app.get('/products')
def products():
 q=request.args.get('q','').lower().strip(); c=request.args.get('category'); xs=PRODUCTS
 if q: xs=[x for x in xs if q in x['name'].lower()]
 if c: xs=[x for x in xs if x['category']==c]
 return jsonify({'count':len(xs),'items':xs})
@app.post('/login')
def login():
 b=request.get_json(silent=True) or {}; u=USERS.get(str(b.get('user_id','')))
 if not u:return jsonify({'error':'invalid_credentials'}),401
 session['user_id']=u['id']; return jsonify({'message':'logged_in','user':u})
@app.get('/me')
def me():
 uid=session.get('user_id')
 if not uid:return jsonify({'error':'not_authenticated'}),401
 return jsonify(USERS[str(uid)])
@app.get('/admin')
def admin():
 uid=session.get('user_id')
 if not uid:return jsonify({'error':'not_authenticated'}),401
 if USERS[str(uid)]['role']!='admin':return jsonify({'error':'forbidden'}),403
 return jsonify({'message':'admin_ok'})
@app.get('/old-home')
def old_home(): return redirect('/health',302)
if __name__=='__main__': app.run(host='127.0.0.1',port=5060)
