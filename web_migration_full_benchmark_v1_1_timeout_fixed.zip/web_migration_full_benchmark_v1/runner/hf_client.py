import os
import time
from openai import OpenAI

MODEL = os.getenv("HF_MODEL", "deepseek-ai/DeepSeek-V3-0324:fastest")
TIMEOUT = float(os.getenv("HF_TIMEOUT", "180"))
RETRIES = int(os.getenv("HF_RETRIES", "4"))


def call(messages, max_tokens=5000):
    """Call Hugging Face Inference Providers with retry/backoff for transient gateway errors."""
    if not os.getenv("HF_TOKEN"):
        raise RuntimeError("HF_TOKEN is not configured.")

    client = OpenAI(
        base_url="https://router.huggingface.co/v1",
        api_key=os.environ["HF_TOKEN"],
        timeout=TIMEOUT,
        max_retries=0,
    )

    last = None
    for attempt in range(RETRIES + 1):
        t0 = time.time()
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                max_tokens=max_tokens,
                temperature=0.2,
            )
            usage = getattr(response, "usage", None)
            return {
                "text": response.choices[0].message.content or "",
                "elapsed": time.time() - t0,
                "usage": None if not usage else {
                    "prompt_tokens": getattr(usage, "prompt_tokens", None),
                    "completion_tokens": getattr(usage, "completion_tokens", None),
                    "total_tokens": getattr(usage, "total_tokens", None),
                },
                "model": MODEL,
                "attempt": attempt + 1,
            }
        except Exception as exc:
            last = exc
            status = getattr(exc, "status_code", None)
            retryable = status in {408, 429, 500, 502, 503, 504} or "504" in str(exc)
            if attempt >= RETRIES or not retryable:
                raise
            delay = min(30, 3 * (2 ** attempt))
            print(f"HF transient error (status={status}); retrying in {delay}s...", flush=True)
            time.sleep(delay)

    raise last
