import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

from hf_client import call

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"
ART = ROOT / "artifacts"
OUT.mkdir(exist_ok=True)
ART.mkdir(exist_ok=True)

APPS = {
    "flask_session": {
        "source": "benchmark/apps/flask_session/app.py",
        "port": 5060,
        "visible": "benchmark/tests/visible/flask_session_test.py",
        "hidden": "benchmark/tests/hidden/flask_session_hidden.py",
    },
    "express_catalog": {
        "source": "benchmark/apps/express_catalog/app.js",
        "port": 5061,
        "visible": "benchmark/tests/visible/express_catalog_test.py",
        "hidden": "benchmark/tests/hidden/express_catalog_hidden.py",
    },
    "fastapi_orders": {
        "source": "benchmark/apps/fastapi_orders/app.py",
        "port": 5062,
        "visible": "benchmark/tests/visible/fastapi_orders_test.py",
        "hidden": "benchmark/tests/hidden/fastapi_orders_hidden.py",
    },
}

SYSTEM = """You are an expert legacy Web migration engineer.
This is a controlled research experiment. Migrate every source application to
Python Flask 3.x using a modular architecture. Preserve externally observable
behavior exactly: paths, methods, status codes, JSON fields, redirects,
sessions, authorization, filtering, and error behavior. Do not weaken
security. The generated application must run with `python app.py` and bind to
127.0.0.1 using the integer in the PORT environment variable (default 5060).
Return complete target files only using:
=== FILE: app.py ===
<content>
=== FILE: routes.py ===
<content>
=== FILE: services.py ===
<content>
=== FILE: repository.py ===
<content>
"""


def parse(text):
    text = text.replace("```python", "").replace("```javascript", "").replace("```", "")
    pattern = re.compile(
        r"=== FILE:\s*([\w./-]+)\s*===\s*\n(.*?)(?=\n=== FILE:|\Z)", re.S
    )
    return {name.strip(): content.strip() + "\n" for name, content in pattern.findall(text)}


def write_artifact(name, mode, cycle, files):
    destination = ART / f"{name}_{mode}_c{cycle}"
    shutil.rmtree(destination, ignore_errors=True)
    destination.mkdir(parents=True)
    for filename, content in files.items():
        path = destination / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    return destination


def evaluate(destination, meta):
    env = os.environ.copy()
    env["PORT"] = str(meta["port"])
    env["TEST_BASE"] = f"http://127.0.0.1:{meta['port']}"
    process = subprocess.Popen(
        [sys.executable, "app.py"],
        cwd=destination,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )
    time.sleep(2)
    try:
        visible = subprocess.run(
            [sys.executable, "-m", "pytest", str(ROOT / meta["visible"]), "-q"],
            cwd=ROOT, env=env, capture_output=True, text=True, timeout=40
        )
        hidden = subprocess.run(
            [sys.executable, "-m", "pytest", str(ROOT / meta["hidden"]), "-q"],
            cwd=ROOT, env=env, capture_output=True, text=True, timeout=40
        )
    finally:
        process.terminate()
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            process.kill()

    return {
        "visible": visible.returncode == 0,
        "hidden": hidden.returncode == 0,
        "pass": visible.returncode == 0 and hidden.returncode == 0,
        "output": visible.stdout + visible.stderr + hidden.stdout + hidden.stderr,
    }


def migrate(source, mode):
    if mode == "direct":
        return call([
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": f"Perform a one-shot migration.\n\nLEGACY SOURCE:\n{source}"},
        ], max_tokens=5000)

    plan = call([
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content":
         "Analyze the migration first. Identify every endpoint, externally observable behavior, "
         "state/session dependency, authorization rule, data dependency, and migration risk. "
         "Do not write code yet.\n\nLEGACY SOURCE:\n" + source},
    ], max_tokens=3500)

    code = call([
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content":
         "Implement the migration plan. Return complete target files.\n\nPLAN:\n" +
         plan["text"] + "\n\nLEGACY SOURCE:\n" + source},
    ], max_tokens=5000)
    return {"plan": plan, "code": code}


def run_one(name, meta, mode):
    source = (ROOT / meta["source"]).read_text(encoding="utf-8")
    base = migrate(source, "direct" if mode == "direct" else "staged")
    current = base if mode == "direct" else base["code"]
    history = []
    max_cycles = 1 if mode != "closed_loop" else 3

    for cycle in range(1, max_cycles + 1):
        text = current["text"]
        files = parse(text)
        artifact = write_artifact(name, mode, cycle, files)
        if "app.py" not in files:
            evaluation = {
                "visible": False, "hidden": False, "pass": False,
                "output": "Missing required app.py in generated target."
            }
        else:
            evaluation = evaluate(artifact, meta)
        record = {
            "cycle": cycle,
            "files": sorted(files),
            "evaluation": evaluation,
            "llm": current,
        }
        history.append(record)

        if mode != "closed_loop" or evaluation["pass"]:
            break

        current = call([
            {"role": "system", "content": SYSTEM +
             "\nYou are now in a repair cycle. Repair ONLY the current migrated implementation "
             "using the independent execution evidence. Return ALL complete target files."},
            {"role": "user", "content":
             "LEGACY SOURCE:\n" + source +
             "\n\nCURRENT MIGRATED SOURCE:\n" + text +
             "\n\nINDEPENDENT TEST EVIDENCE:\n" + evaluation["output"][-14000:]},
        ], max_tokens=5000)

    return {
        "app": name,
        "mode": mode,
        "cycles": len(history),
        "initial_pass": history[0]["evaluation"]["pass"],
        "final_pass": history[-1]["evaluation"]["pass"],
        "history": history,
    }


def main():
    if not os.getenv("HF_TOKEN"):
        raise SystemExit("HF_TOKEN is not configured.")

    all_results = []
    print("Using model:", os.getenv("HF_MODEL", "deepseek-ai/DeepSeek-V3-0324:fastest"))
    for name, meta in APPS.items():
        print(f"\n=== {name} ===")
        for mode in ("direct", "staged", "closed_loop"):
            print(f"[{mode}] starting...", flush=True)
            try:
                result = run_one(name, meta, mode)
                all_results.append(result)
                print(f"[{mode}] final_pass={result['final_pass']} cycles={result['cycles']}", flush=True)
            except Exception as exc:
                all_results.append({"app": name, "mode": mode, "error": repr(exc)})
                print(f"[{mode}] ERROR: {exc}", flush=True)

    output = OUT / "benchmark_raw.json"
    output.write_text(json.dumps(all_results, indent=2, ensure_ascii=False), encoding="utf-8")
    print("\nFULL_BENCHMARK_COMPLETE")
    print("Evidence:", output)


if __name__ == "__main__":
    main()
