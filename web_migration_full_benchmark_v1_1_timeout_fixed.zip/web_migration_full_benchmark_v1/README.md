# Web Migration Full Benchmark V1.1 — timeout-fixed

This is the corrected benchmark package. It addresses the Hugging Face 504 failure by:

- using the Hugging Face OpenAI-compatible router with the `:fastest` policy by default;
- using a 180-second client timeout;
- retrying transient 408/429/500/502/503/504 responses with exponential backoff;
- reducing generation limits to make benchmark calls less likely to hit gateway timeouts;
- continuing to log each LLM call and each migration cycle;
- standardizing the target of all three cases to Python Flask 3.x for controlled comparison;
- using the `PORT` and `TEST_BASE` environment variables so the three cases do not depend on hard-coded ports.

## Run in PowerShell

```powershell
pip install -r requirements.txt
$env:HF_TOKEN="hf_YOUR_NEW_TOKEN"
$env:HF_MODEL="deepseek-ai/DeepSeek-V3-0324:fastest"
python runner/run_benchmark.py
```

Optional:

```powershell
$env:HF_TIMEOUT="180"
$env:HF_RETRIES="4"
```

Evidence is written to `results\benchmark_raw.json` and generated applications to `artifacts\`.

Do not put the token into source code or upload it to the repository.
