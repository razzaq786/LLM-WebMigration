# Verification-Guided LLM Web Migration — Pilot V2

This version fixes the pilot controller so closed-loop repair receives the complete current migrated source plus exact independent test failures. It also adds hidden tests, static architecture-oriented metrics, per-cycle artifacts, and complete LLM/test logging.

## PowerShell

```powershell
pip install -U -r requirements.txt
$env:HF_TOKEN="hf_YOUR_NEW_TOKEN"
$env:HF_MODEL="deepseek-ai/DeepSeek-V3-0324"
python runner/run_pilot.py
```

Do not put your token into source files or send it in chat.

## Evidence

`results/pilot_v2_raw.json` contains all recorded LLM responses, token usage, latency, test outcomes, hidden-test outcomes, repair cycles, and static metrics.

`generated/` contains per-treatment/per-cycle source artifacts.

## Important

This is still a pilot. Its purpose is to validate the experimental controller before scaling to a multi-application study. Do not present pilot data as the final statistical study.
