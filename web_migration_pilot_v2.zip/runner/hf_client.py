import os,time
from openai import OpenAI
MODEL=os.getenv("HF_MODEL","deepseek-ai/DeepSeek-V3-0324")

def call(messages,max_tokens=12000,temperature=0.2):
    token=os.getenv("HF_TOKEN")
    if not token: raise RuntimeError("HF_TOKEN is not configured.")
    client=OpenAI(base_url="https://router.huggingface.co/v1",api_key=token)
    t0=time.time()
    response=client.chat.completions.create(model=MODEL,messages=messages,max_tokens=max_tokens,temperature=temperature)
    usage=getattr(response,"usage",None)
    return {"text":response.choices[0].message.content or "","elapsed":time.time()-t0,"usage":None if not usage else {"prompt_tokens":getattr(usage,"prompt_tokens",None),"completion_tokens":getattr(usage,"completion_tokens",None),"total_tokens":getattr(usage,"total_tokens",None)},"model":MODEL}
