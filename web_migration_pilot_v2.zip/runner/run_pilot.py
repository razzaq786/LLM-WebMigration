import os,re,json,shutil,subprocess,sys,time,ast
from pathlib import Path
from hf_client import call
ROOT=Path(__file__).resolve().parents[1]; LEGACY=(ROOT/"legacy/app.py").read_text(encoding="utf-8"); GEN=ROOT/"generated"; RES=ROOT/"results"; GEN.mkdir(exist_ok=True); RES.mkdir(exist_ok=True)
SYSTEM="""You are an expert Web software engineer performing a controlled legacy Web modernization experiment. Modernize the supplied Flask application into a modular Flask application with app.py, routes.py, services.py and repository.py. Preserve every observable endpoint, HTTP status, JSON field, redirect, session and authorization behavior. Do not weaken security.
Return ONLY complete files using this exact format:
=== FILE: app.py ===
<content>
=== FILE: routes.py ===
<content>
=== FILE: services.py ===
<content>
=== FILE: repository.py ===
<content>
The application must run with `python app.py` on port 5056.
"""

def normalize(text):
    if not isinstance(text,str): raise TypeError(f"Expected model text, got {type(text).__name__}")
    return text.replace("```python","").replace("```text","").replace("```","")

def extract_files(text):
    text=normalize(text); pattern=re.compile(r"===\s*FILE:\s*([A-Za-z0-9_.\-/]+)\s*===\s*\n(.*?)(?=\n===\s*FILE:|\Z)",re.S)
    return {n.strip():c.strip()+"\n" for n,c in pattern.findall(text)}

def write_files(files,dest):
    if dest.exists(): shutil.rmtree(dest)
    dest.mkdir(parents=True)
    for n,c in files.items():
        p=dest/n; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(c,encoding="utf-8")

def start_app(dest):
    return subprocess.Popen([sys.executable,"app.py"],cwd=dest,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)

def run_suite(dest,suite):
    proc=start_app(dest); time.sleep(2); start=time.time()
    try:
        r=subprocess.run([sys.executable,"-m","pytest",str(ROOT/"evaluation"/suite),"-q"],cwd=ROOT,capture_output=True,text=True,timeout=45)
    finally:
        proc.terminate()
        try: proc.wait(timeout=3)
        except subprocess.TimeoutExpired: proc.kill()
    output=r.stdout+"\n"+r.stderr
    passed=re.search(r"(\d+) passed",output); failed=re.search(r"(\d+) failed",output)
    return {"returncode":r.returncode,"pass":r.returncode==0,"passed":int(passed.group(1)) if passed else 0,"failed":int(failed.group(1)) if failed else 0,"output":output,"wall_time":time.time()-start}

def static_metrics(dest):
    pyfiles=list(dest.glob("*.py")); total_lines=0; funcs=0; imports=0
    for p in pyfiles:
        txt=p.read_text(encoding="utf-8",errors="ignore"); total_lines+=len(txt.splitlines())
        try:
            tree=ast.parse(txt); funcs+=sum(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) for n in ast.walk(tree)); imports+=sum(isinstance(n,(ast.Import,ast.ImportFrom)) for n in ast.walk(tree))
        except SyntaxError: pass
    duplicate_lines=0; seen={}
    for p in pyfiles:
        lines=[x.strip() for x in p.read_text(encoding="utf-8",errors="ignore").splitlines() if x.strip()]
        for x in lines: seen[x]=seen.get(x,0)+1
    duplicate_lines=sum(v-1 for v in seen.values() if v>1)
    return {"python_files":len(pyfiles),"lines":total_lines,"functions":funcs,"imports":imports,"duplicate_nonempty_lines":duplicate_lines}

def evaluate(name,files):
    dest=GEN/name; write_files(files,dest)
    result={"files":sorted(files),"static":static_metrics(dest)}
    if "app.py" not in files: result.update({"pass":False,"visible":None,"hidden":None,"output":"No app.py generated."}); return result
    result["visible"]=run_suite(dest,"test_visible.py"); result["hidden"]=run_suite(dest,"test_hidden.py"); result["pass"]=result["visible"]["pass"] and result["hidden"]["pass"]; return result

def direct():
    return call([{"role":"system","content":SYSTEM},{"role":"user","content":f"Perform a one-shot migration.\n\nLEGACY APPLICATION:\n```python\n{LEGACY}\n```"}])

def staged():
    plan=call([{"role":"system","content":SYSTEM},{"role":"user","content":f"Analyze this legacy Web application and produce a migration plan. Identify endpoints, externally observable behavior, sessions, authorization, data access, dependencies and target module responsibilities. Do not write code yet.\n\nLEGACY:\n{LEGACY}"}],7000)
    code=call([{"role":"system","content":SYSTEM},{"role":"user","content":f"Implement the following migration plan. Return complete app.py, routes.py, services.py and repository.py.\n\nPLAN:\n{plan['text']}\n\nLEGACY:\n{LEGACY}"}])
    return {"plan":plan,"code":code}

def closed_loop():
    staged_result=staged(); current=staged_result["code"]; history=[]; current_files={}
    for cycle in range(1,4):
        files=extract_files(current["text"]); current_files=files
        evaluation=evaluate(f"closed_loop_cycle_{cycle}",files)
        history.append({"cycle":cycle,"evaluation":evaluation,"source_files":sorted(files)})
        if evaluation["pass"]: break
        source_bundle="\n\n".join(f"=== FILE: {n} ===\n{c}" for n,c in files.items())
        failure=(evaluation["visible"]["output"] if evaluation.get("visible") else "")+"\n"+(evaluation["hidden"]["output"] if evaluation.get("hidden") else "")
        current=call([{"role":"system","content":SYSTEM},{"role":"user","content":f"Repair the CURRENT migrated application; do not regenerate it from scratch. You have the current complete source, the legacy source, and independent executable test failures. Return ALL complete files. Preserve all already-correct behavior. Do not remove or weaken authentication/authorization. Do not modify tests.\n\nCURRENT MIGRATED SOURCE:\n{source_bundle}\n\nTEST FAILURE EVIDENCE:\n{failure[-16000:]}\n\nLEGACY SOURCE:\n{LEGACY}"}],14000)
    return {"initial_plan":staged_result["plan"],"initial_code":staged_result["code"],"cycles":len(history),"history":history,"final_code":current,"final_files":sorted(current_files)}

def main():
    if not os.getenv("HF_TOKEN"): raise SystemExit("HF_TOKEN is not configured.")
    raw={"experiment":"pilot_v2","model":os.getenv("HF_MODEL","deepseek-ai/DeepSeek-V3-0324"),"started_at":time.strftime("%Y-%m-%dT%H:%M:%S")}
    print("[1/3] Direct..."); d=direct(); raw["direct"]={"llm":d,"evaluation":evaluate("direct",extract_files(d["text"]))}
    print("[2/3] Staged..."); s=staged(); raw["staged"]={"llm":{"plan":s["plan"],"code":s["code"]},"evaluation":evaluate("staged",extract_files(s["code"]["text"]))}
    print("[3/3] Closed-loop..."); raw["closed_loop"]=closed_loop()
    out=RES/"pilot_v2_raw.json"; out.write_text(json.dumps(raw,indent=2,ensure_ascii=False),encoding="utf-8"); print("\nPILOT_V2_COMPLETE"); print(f"Raw evidence: {out}")
if __name__=="__main__": main()
