import requests
BASE="http://127.0.0.1:5056"

def test_unauthenticated_me_is_401():
    r=requests.get(BASE+"/me",timeout=5); assert r.status_code==401 and r.json()["error"]=="not_authenticated"
def test_unauthenticated_admin_is_401():
    r=requests.get(BASE+"/admin",timeout=5); assert r.status_code==401 and r.json()["error"]=="not_authenticated"
def test_invalid_login_is_401():
    r=requests.post(BASE+"/login",json={"user_id":"999"},timeout=5); assert r.status_code==401 and r.json()["error"]=="invalid_credentials"
def test_combined_product_filters():
    r=requests.get(BASE+"/products",params={"q":"pen","category":"stationery"},timeout=5); assert r.status_code==200 and r.json()["count"]==1 and r.json()["items"][0]["name"]=="Pen"
def test_case_insensitive_search():
    r=requests.get(BASE+"/products",params={"q":"PEN"},timeout=5); assert r.status_code==200 and r.json()["count"]==1
def test_missing_category_returns_empty():
    r=requests.get(BASE+"/products",params={"category":"missing"},timeout=5); assert r.status_code==200 and r.json()["count"]==0 and r.json()["items"]==[]
def test_redirect_target_is_preserved():
    r=requests.get(BASE+"/old-home",allow_redirects=False,timeout=5); assert r.headers.get("Location")=="/health"
def test_non_admin_cannot_access_admin_after_session():
    s=requests.Session(); s.post(BASE+"/login",json={"user_id":"3"},timeout=5); r=s.get(BASE+"/admin",timeout=5); assert r.status_code==403 and r.json()["error"]=="forbidden"
